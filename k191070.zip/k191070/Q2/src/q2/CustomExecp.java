package q2;

public class CustomExecp extends Exception{

	public CustomExecp(String s) {
		
	}
	String toString(String s) {
		return "Exception Caught: " + s;
	}
	
	
}
